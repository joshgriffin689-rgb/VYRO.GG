// Paste your values from Supabase -> Project Settings -> API.
// The anon key is meant to be public. Security comes from the rules in supabase-setup.sql.
window.VYRO_CONFIG = {
  url: "https://YOUR-PROJECT.supabase.co",
  key: "YOUR-ANON-KEY",
  supportEmail: "YOUR-EMAIL@example.com"
};

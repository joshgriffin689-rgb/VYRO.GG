-- Run this ONCE in Supabase -> SQL Editor, after supabase-setup.sql.

-- Timestamps so the Social tab can show recent follows and likes
alter table public.likes   add column if not exists created_at timestamptz not null default now();
alter table public.follows add column if not exists created_at timestamptz not null default now();

-- Reports: anyone logged in can file one, but nobody can read them through the app.
-- You review them in Supabase -> Table Editor -> reports.
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  reason text not null check (char_length(reason) <= 100),
  created_at timestamptz not null default now(),
  unique (reporter_id, video_id)
);

alter table public.reports enable row level security;

create policy "file a report" on public.reports for insert to authenticated
  with check (auth.uid() = reporter_id);

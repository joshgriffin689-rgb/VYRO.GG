-- Run ONCE in Supabase -> SQL Editor, after supabase-setup.sql and supabase-update.sql.

-- 1. Blocking
create table public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
alter table public.blocks enable row level security;
create policy "see own blocks" on public.blocks for select to authenticated
  using (auth.uid() = blocker_id);
create policy "block as yourself" on public.blocks for insert to authenticated
  with check (auth.uid() = blocker_id);
create policy "unblock as yourself" on public.blocks for delete to authenticated
  using (auth.uid() = blocker_id);

-- 2. Auto-hide: a video reported by 3 different people is hidden from everyone but its owner
alter table public.videos add column if not exists hidden boolean not null default false;
drop policy if exists "videos readable" on public.videos;
create policy "videos readable" on public.videos for select
  using (not hidden or auth.uid() = user_id);

create function public.auto_hide_reported() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.reports where video_id = new.video_id) >= 3 then
    update public.videos set hidden = true where id = new.video_id;
  end if;
  return new;
end $$;

create trigger hide_after_reports
  after insert on public.reports
  for each row execute function public.auto_hide_reported();

-- 3. Let people delete their own account
create function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ADMIN TOOLS (run these by hand when needed)
-- See reports, newest first:
--   select r.created_at, r.reason, v.id as video_id, v.caption, p.username
--   from reports r join videos v on v.id = r.video_id join profiles p on p.id = v.user_id
--   order by r.created_at desc;
-- Remove a video (then delete its file in Storage > videos):
--   delete from videos where id = 'VIDEO-ID-HERE';
-- Ban a user and delete their account and posts (then delete their folder in Storage):
--   delete from auth.users where id = (select id from profiles where username = 'USERNAME');

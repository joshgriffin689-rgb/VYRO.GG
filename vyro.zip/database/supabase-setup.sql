-- VYRO database setup. Paste into Supabase -> SQL Editor -> Run (once).

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9_]{1,24}$'),
  display_name text not null default '',
  bio text not null default '' check (char_length(bio) <= 200),
  created_at timestamptz not null default now()
);

create table public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_path text not null,
  caption text not null default '' check (char_length(caption) <= 150),
  created_at timestamptz not null default now()
);

create table public.likes (
  user_id uuid references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete cascade,
  primary key (user_id, video_id)
);

create table public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

-- Create a profile automatically when someone signs up
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare uname text;
begin
  uname := lower(regexp_replace(coalesce(new.raw_user_meta_data->>'username', ''), '[^a-z0-9_]', '', 'gi'));
  if uname = '' then uname := 'user' || substr(replace(new.id::text, '-', ''), 1, 8); end if;
  uname := left(uname, 24);
  insert into public.profiles (id, username, display_name) values (new.id, uname, uname);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Row Level Security: this is what keeps the public anon key safe
alter table public.profiles enable row level security;
alter table public.videos   enable row level security;
alter table public.likes    enable row level security;
alter table public.follows  enable row level security;

create policy "profiles readable" on public.profiles for select using (true);
create policy "edit own profile" on public.profiles for update
  using (auth.uid() = id) with check (auth.uid() = id);

create policy "videos readable" on public.videos for select using (true);
create policy "post own videos" on public.videos for insert to authenticated
  with check (auth.uid() = user_id);
create policy "delete own videos" on public.videos for delete to authenticated
  using (auth.uid() = user_id);

create policy "likes readable" on public.likes for select using (true);
create policy "like as yourself" on public.likes for insert to authenticated
  with check (auth.uid() = user_id);
create policy "unlike as yourself" on public.likes for delete to authenticated
  using (auth.uid() = user_id);

create policy "follows readable" on public.follows for select using (true);
create policy "follow as yourself" on public.follows for insert to authenticated
  with check (auth.uid() = follower_id);
create policy "unfollow as yourself" on public.follows for delete to authenticated
  using (auth.uid() = follower_id);

-- Video storage: public to watch, but you can only upload into your own folder
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('videos', 'videos', true, 52428800,
        array['video/mp4', 'video/webm', 'video/quicktime'])
on conflict (id) do nothing;

create policy "videos bucket readable" on storage.objects for select
  using (bucket_id = 'videos');
create policy "upload to own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "delete own files" on storage.objects for delete to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
